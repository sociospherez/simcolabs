import { Routes, Route } from 'react-router-dom';
import PageShell from '../components/layout/PageShell';
import Home from '../pages/Home';
import Showcase from '../pages/Showcase';
import Research from '../pages/Research';
import About from '../pages/About';
import Contact from '../pages/Contact';
import ProjectDetail from '../pages/ProjectDetail';

export default function AppRouter() {
  return (
    <PageShell>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/showcase" element={<Showcase />} />
        <Route path="/research" element={<Research />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/projects/:slug" element={<ProjectDetail />} />
      </Routes>
    </PageShell>
  );
}
